package com.example.modularloginmvc.controller;

public class UserController {
}
