package com.example.modularloginmvc.datasource;

public class AppDataSource {
}
